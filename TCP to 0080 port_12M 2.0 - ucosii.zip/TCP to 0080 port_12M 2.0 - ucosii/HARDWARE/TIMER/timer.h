#ifndef __TIMER_H
#define __TIMER_H
#include "sys.h"   

typedef struct 
{
  //��ʱʱ�䡢�ϵ�ʱ�估��־λ
	u8 Tmr_Time_M;
	u8 Tmr_Time_S;
	u8 Tmr_Time_Flag;			
	u8 Relay_Time_M;
	u8 Relay_Time_S;
	u8 Relay_Time_Flag;
	  //DM9006 timer 1  
  u8 Tmr_Time1_M;
	u8 Tmr_Time1_S;
	u8 Tmr_Time1_Flag;			

  //�������еĶ�ʱʱ�䡢�ϵ�ʱ��
    u8 Tmr_Time_m;
    u8 Tmr_Time_s;
    u8 Relay_Time_m;
    u8 Relay_Time_s;
    u8 Tmr_Time1_m;
    u8 Tmr_Time1_s;
}Timer_Obj;					 
extern Timer_Obj Timer;	
void TIM1_Int_Init(u16 arr,u16 psc); //DM9006 timer 1
void TIM3_Int_Init(u16 arr,u16 psc);
void TIM4_Int_Init(u16 arr,u16 psc);

#endif
