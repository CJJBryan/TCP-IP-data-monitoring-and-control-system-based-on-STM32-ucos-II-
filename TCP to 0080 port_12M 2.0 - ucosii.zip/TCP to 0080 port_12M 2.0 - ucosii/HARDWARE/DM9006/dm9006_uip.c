#include "stm32f10x.h"
#include <stdio.h>

#include "dm9006_uip.h"
 u16 port=80;  //Ĭ��80�˿�

#define  EXINIT                    GPIO_Pin_0    // PB0
#define  CMD                       GPIO_Pin_15 	 // PB15
#define	 CS                        GPIO_Pin_12	 // PB12
#define  IOW                       GPIO_Pin_13   // PB13
#define  IOR                       GPIO_Pin_14   // PB14
//#define  DATA                      GPIOC
#define  CMD_PORT                  GPIOB
#define  CS_PORT                   GPIOB
#define  IOW_PORT                  GPIOB
#define  IOR_PORT                  GPIOB
#define  CONTROL_PORT              GPIOB
#define  EXINT_PORT                GPIOB
//#define  DATA_PORT                 GPIOC         // PC0~15
#define  DATA_PORT                 GPIOD         // PD0~15  

//#define  GPIOC_CRL                 (*(volatile unsigned long *)GPIOC_BASE) //GPIOC = 0x40011000
//#define  DATA_PORT_CRL             GPIOC_CRL

#define  GPIOD_CRL                 (*(volatile unsigned long *)GPIOD_BASE) //GPIOD = 0x40011400
#define  DATA_PORT_CRL             GPIOD_CRL

#define  DM9000_IO                 0    
#define  DM9000_DATA               1    //CMD = 1 -->   in data 
#define  DM9000_INDEX              0    //CMD = 0 -->   out data 

#define  DM9000X_CMD(dcmd)         (dcmd == 0x01)                 ?          \
                                   (CMD_PORT->ODR |= GPIO_Pin_15) :          \
                                   (CMD_PORT->ODR &= ~GPIO_Pin_15)           

#define  DM9000X_CS(dcs)           (dcs == 0x01)                  ?          \
                                   (CS_PORT->ODR |= GPIO_Pin_12)  :          \
                                   (CS_PORT->ODR &= ~GPIO_Pin_12)           

#define  DM9000X_IOW(dwrite)       (dwrite == 0x01)               ?          \
                                   (IOW_PORT->ODR |= GPIO_Pin_13) :          \
                                   (IOW_PORT->ODR &= ~GPIO_Pin_13)   
                                   
#define  DM9000X_IOR(dread)        (dread == 0x01)                ?          \
                                   (IOR_PORT->ODR |= GPIO_Pin_14) :          \
                                   (IOR_PORT->ODR &= ~GPIO_Pin_14)   


#define  DM9000X_DATA_OUT(ddata)   (DATA_PORT->ODR = ddata)    
#define  DM9000X_DATA_IN()         (DATA_PORT->IDR)

#define DM9000X_BYTE_MODE          0x01
#define DM9000X_WORD_MODE          0x00

#define DM9000_PHY		0x40	/* PHY address 0x01 */
u8 dmfe_port_mode;
uint8_t fix_mac[6];

static dm9000_delay(u32 delay)
{
       while (delay--);
}

void dm9000x_gpio_inital(void)
{
    GPIO_InitTypeDef GPIO_dm9000x;

	RCC_APB2PeriphClockCmd( RCC_APB2Periph_GPIOB , ENABLE); 	
//	RCC_APB2PeriphClockCmd( RCC_APB2Periph_GPIOC , ENABLE);
	RCC_APB2PeriphClockCmd( RCC_APB2Periph_GPIOD , ENABLE);   

	/* Configure control io as output push-pull */
	GPIO_dm9000x.GPIO_Pin = CMD | CS | IOW | IOR;
//	GPIO_dm9000x.GPIO_Speed = GPIO_Speed_50MHz; 
	GPIO_dm9000x.GPIO_Speed = GPIO_Speed_2MHz;   //???
	GPIO_dm9000x.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_Init( CONTROL_PORT, &GPIO_dm9000x );

	/* Configure data io as inout */
	GPIO_dm9000x.GPIO_Pin = GPIO_Pin_All;
//	GPIO_dm9000x.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_dm9000x.GPIO_Speed = GPIO_Speed_2MHz;
	GPIO_dm9000x.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_Init( DATA_PORT, &GPIO_dm9000x );

	GPIO_dm9000x.GPIO_Pin = EXINIT;
    GPIO_dm9000x.GPIO_Speed = GPIO_Speed_10MHz;
    GPIO_dm9000x.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    GPIO_Init(EXINT_PORT,&GPIO_dm9000x);
}

/*********************************************************************************************************************/
static __inline void dm9000_out_byte(u16 outdata, u8 reg)
{
    DATA_PORT_CRL = 0x33333333;
	
	DM9000X_DATA_OUT(outdata); 	 //outdata = register offset or value      
    DM9000X_CMD(reg);          //reg = 	DM9000_INDEX (0) or DM9000_DATA (1)		   
    DM9000X_CS(0);				   
    DM9000X_IOR(1);				   
    DM9000X_IOW(0);
//    dm9000_delay(20);			   
    DM9000X_IOW(1);
    DM9000X_CS(1); 
	//dm9000_delay(50);
}

static __inline u16 dm9000_in_byte(u8 reg)
{
	u16 indata;
	
    DATA_PORT_CRL = 0x88888888;	       
     
    DM9000X_CMD(reg);			  //DM9000_DATA (1)
    DM9000X_CS(0);				  
    DM9000X_IOR(0);				  
    DM9000X_IOW(0);                   
//	  dm9000_delay(200);			  
	  indata = DM9000X_DATA_IN();  
    DM9000X_IOW(0);				  
    DM9000X_CS(1);
	//dm9000_delay(50);

    return indata;
}

static u16 ior(unsigned char reg)
{
    u16 data = 0;
	dm9000_out_byte(reg, DM9000_INDEX); // CMD = 0 (DM9000_INDEX) out, register address
	data=dm9000_in_byte(DM9000_DATA); //CMD = 1 (DM9000_DATA) in, read register data 
	   
    return data;
}

static void iow(unsigned char reg, u16 value)
{
    dm9000_out_byte(reg,   DM9000_INDEX);   
    dm9000_out_byte(value, DM9000_DATA); 
}

//Stone add for DM9003 switch 
//====================================================================
static int
dm9003_phy_read(int phy_reg_unused, int reg)
{
	int ret;

	/* Fill the phyxcer register into REG_0C */
	iow(DM9000_EPAR, (phy_reg_unused<<6) | reg);  

	iow(DM9000_EPCR, EPCR_ERPRR | EPCR_EPOS);	/* Issue phyxcer read command */

  dm9000_delay (5000);

	iow(DM9000_EPCR, 0x0);	/* Clear phyxcer read command */ 

	/* The read data keeps on REG_0D & REG_0E */
	ret = (ior(DM9000_EPDRH) << 8) | ior(DM9000_EPDRL);

	return ret;
}

/*
 *   Write a word to phyxcer
 */
static void
dm9003_phy_write(int phyaddr_unused, int reg, int value)
{
	/* Fill the phyxcer register into REG_0C */
	iow(DM9000_EPAR, (phyaddr_unused<<6) | reg); //Stone add for phyaddr != 1;

	/* Fill the written data into REG_0D & REG_0E */
	iow(DM9000_EPDRL, value);
	iow(DM9000_EPDRH, value >> 8);

	iow(DM9000_EPCR, EPCR_EPOS | EPCR_ERPRW);	/* Issue phyxcer write command */

  /* Wait write complete */
	dm9000_delay (5000);

	iow(DM9000_EPCR, 0x0);	/* Clear phyxcer write command */
}

static void
dm9000_phy_write(int phyaddr_unused, int reg, int value)
{
//	unsigned long flags;
//	unsigned long reg_save;

	/* Fill the phyxcer register into REG_0C */
	iow(DM9000_EPAR, DM9000_PHY | reg);
  
	/* Fill the written data into REG_0D & REG_0E */
	iow(DM9000_EPDRL, value);
	iow(DM9000_EPDRH, value >> 8);
  iow(DM9000_EPCR, EPCR_EPOS | EPCR_ERPRW);	/* Issue phyxcer write command */
  
  /* Wait write complete */
  dm9000_delay (5000);

	iow(DM9000_EPCR, 0x0);	/* Clear phyxcer write command */
}

//Stone Add for support DM9003 
void set_DM9003_PHY_mode(void)
{
	int i;
	u16 phy_reg0 = 0x1200;/* Auto-negotiation & Restart Auto-negotiation */
	u16 phy_reg4 = 0x01e1;/* Default flow control disable*/

	for (i=0; i<dmfe_port_mode; i++) /* reset PHY */
		dm9003_phy_write(i, 0, 0x8000);
	/* wait for PHY ready */
		for(i=0; i<dmfe_port_mode; i++)
		{
		  dm9003_phy_write(i, 4, phy_reg4);
			dm9003_phy_write(i, 0, phy_reg0);
	
		}
}


static void dm9003_vlan_group_map(u8 reg_group, u8 mapping)
{
  iow(reg_group,mapping);	
}

static int dm9003_vlan_port_vid(int port, u8 VID)
{
	if((port<0)||(port > 3)) 
	{
//		printk("<DM9013>Port number error\n ");
		return 1;
	}

  iow(DM9KS_PIndex, port);
	iow(DM9KS_VLAN_TAGL, VID);	
		
	return 0;
}

static int dm9003_make_mask(int p3, int p2, int p1, int p0)
{
	p3 = p3 ? 1:0;
	p2 = p2 ? 1:0;
	p1 = p1 ? 1:0;
	p0 = p0 ? 1:0;
	
	return (p3<<3)|(p2<<2)|(p1<<1)|p0;
}

static void dm9003_switch_reset(void)
{
	int i;
	/* reset VLAN mapping table */
	for (i=0xb0; i<=0xbf; i++)
		dm9003_vlan_group_map(i, dm9003_make_mask(1, 1, 1, 1));
	/* reset Per-Port VID*/
	for(i=0; i<4; i++)
		dm9003_vlan_port_vid(i,1);

	/* reset VLAN control */
	iow (DM9KS_VLANCR, 0);

	/* reset Per-Port switch control */
	for(i=0; i<dmfe_port_mode; i++)
	{
		iow(DM9KS_PIndex, i);
		iow(0x61, 0);
		iow(0x66, 0);
		iow(0x67, 0);
		iow(0x6D, 0);
		iow(0x6F, 0);
	}
		
}


static void
dm9000_init_dm9003(void)
{
	unsigned int imr, temp;
	dmfe_port_mode = 0;

	//Stone add for support DM9003
	dmfe_port_mode= (ior(DM9KS_MONITOR2)&(1<<6)) ? 2:3; /* DM9013 is 2 port mode or 3 port mode */
//	printf("dmfe_port_mode %x \r\n", dmfe_port_mode);
	

	/* GPIO0 on pre-activate PHY */
	iow(DM9000_GPCR, GPCR_GEP_CNTL);	/* Let GPIO0 output */
	iow(DM9000_GPR, 0);	/* Enable PHY */

  dm9000_delay (5000);

  dm9000_phy_write(0, 0, 0x8000); //V_R2 reset PHY
  dm9000_delay (5000);

	//Stone add	
	set_DM9003_PHY_mode();
  dm9003_switch_reset();


	/* Program operating register */
  iow(DM9000_TCR, 0);	        /* TX Polling clear */
	iow(DM9000_BPTR, 0x3f);	/* Less 3Kb, 200us */
//	iow(DM9000_FCR, 0xff);	/* Flow Control */
	iow(DM9000_SMCR, 0);        /* Special Mode */
	/* clear TX status */
	iow(DM9000_NSR, NSR_WAKEST | NSR_TX2END | NSR_TX1END);
	iow(DM9000_ISR, ISR_CLR_STATUS); /* Clear interrupt status */


	imr = IMR_PAR | IMR_PTM | IMR_PRM;
	imr |= IMR_LNKCHNG;

	/* Enable TX/RX interrupt mask */
	iow(DM9000_IMR, imr);

	dm9000_phy_write(0, 27, 0xE100); //V_R1
//#if 0	
	//Stone add for enable promiscuous mode; port 3 as sniffer port, port 0 as TX/RX monitor port
	temp = ior(DM9000_RCR);
	//printf("1. Reg 0x05 = %x \r\n", temp);
	temp |= 0x2;
	iow(DM9000_RCR,temp); //enable promiscuous mode
	
	temp = ior(DM9000_RCR);
//	printf("1.1 Reg 0x05 = %x \r\n", temp);
//#if 0	
	temp = ior(DM9KS_SCR);
//	printf("2. Reg 0x52 = %x \r\n", temp);
	
	temp |= (0x3 << 3);
	
	iow(DM9KS_SCR, temp);  //port 3 as sniffer port
	temp = ior(DM9KS_SCR);
//	printf("2.1 Reg 0x52 = %x \r\n", temp);
	
	
	iow(DM9KS_PIndex, 0); //switch port index first!
	temp = ior(DM9KS_PFCR);
//	printf("3. Reg 0x65 = %x \r\n", temp);
//	temp |= 0x60; //Enable TX (0x40)+ RX packet(0x20) monitored
  temp |= 0x20; //port 0 RX packet monitored
	iow(DM9KS_PFCR, temp);
	
	temp = ior(DM9KS_PFCR);
//	printf("3.1 Reg 0x65 = %x \r\n", temp);
	
//#endif

  iow(DM9KS_PIndex, 0); //switch port index first!
	iow(DM9KS_VLAN_TAGL, 0x02);  //write port 0 VID to 0x02
	
  iow(DM9KS_PIndex, 1); //switch port index first!
	iow(DM9KS_VLAN_TAGL, 0x02);  //write port 0 VID to 0x02
	
	iow(0xB2, 0x03); //Port-Based VLAN mapping table Register, 0xB2 set to 0x03 (port 0 group port 1)
   
}



//====================================================================


unsigned int dm9000x_read_id(void)
{
    u32 id = 0x00;
	id  = ior( DM9000_VIDL );      
	id |= ior( DM9000_VIDH ) << 8; 
	id |= ior( DM9000_PIDL ) << 16;
	id |= ior( DM9000_PIDH ) << 24;
	
//	printf("DM9000x ID:0x%x \n",id);
	
	if(DM9000_ID == id)
	     return  id;
	
	return 0;	 
}

void dm9000x_inital(u8 *macaddr)
{
	unsigned char i = 0x00;
//  unsigned int temp;
  
	dm9000x_gpio_inital();
	dm9000_delay (5000);
	for (i=0; i<100; i++)
//	    printf(".");
	    
//	printf("\r\n");
    /* ���� GPCR(1EH) bit[0]=1��ʹDM9000��GPIO3Ϊ��� */
	iow(DM9000_GPCR, 0x01);

    /* GPR bit[0]=0 ʹDM9000��GPIO3���Ϊ���Լ����ڲ�PHY */
    iow(DM9000_GPR, 0x00);
	
    /* ��ʱ2ms���ϵȴ�PHY�ϵ� */
    dm9000_delay(20000);

	/* ������λ */
    iow(DM9000_NCR, 0x03);

	/* ��ʱ20us���ϵȴ�������λ��� */
    dm9000_delay(5000);

	/* ��λ��ɣ�������������ģʽ */
    iow(DM9000_NCR, 0x00);

	/* �ڶ���������λ��Ϊ��ȷ��������λ��ȫ�ɹ����˲����Ǳ�Ҫ�� */
    iow(DM9000_NCR, 0x03);

    dm9000_delay(5000);
    iow(DM9000_NCR, 0x00);

    /*���������DM9000�ĸ�λ����*/

	 /* ���� GPCR(1EH) bit[0]=1��ʹDM9000��GPIO3Ϊ��� */
	iow(DM9000_GPCR, 0x01);

    /* GPR bit[0]=0 ʹDM9000��GPIO3���Ϊ���Լ����ڲ�PHY */
    iow(DM9000_GPR, 0x00);

	dm9000x_read_id();
	
    /*  */
    iow(DM9000_NSR, 0x2c);//�������״̬��־λ

    iow(DM9000_ISR, 0x3f);//��������жϱ�־λ

    iow(DM9000_RCR, 0x39);//���տ���

    iow(DM9000_TCR, 0x00);//���Ϳ���

    iow(DM9000_BPTR, 0x3f);

    iow(DM9000_FCTR, 0x3a);

//    iow(DM9000_FCR, 0xff);

    iow(DM9000_SMCR, 0x00);

    for(i=0; i<6; i++)
        {
        iow(DM9000_PAR + i, macaddr[i]);
        fix_mac[i] = macaddr[i];
    	}

//    printf("Mac: ");
	for(i=0; i<6; i++)
//        printf("%x:",ior(DM9000_PAR+i));
//	printf("\n");


    iow(DM9000_NSR, 0x2c);

    iow(DM9000_ISR, 0x3f);

    iow(DM9000_IMR, 0x81);
    
  
  dm9000_init_dm9003();
  
  iow(DM9KS_DBDC, 0x63);
    
}

void dm9000x_sendpacket( uint8_t* packet, uint16_t len)
{
    uint16_t length = len;
	uint16_t io_mode;
		
    iow(DM9000_IMR, 0x80);//�Ƚ�ֹ�����жϣ���ֹ�ڷ�������ʱ���жϸ���

	io_mode = ior(DM9000_ISR) >> 7;  
	
	if(DM9000X_BYTE_MODE == (io_mode & 0x01))
		{
		while(length--)
			{
			iow(DM9000_MWCMD,*(packet++));
			}
		}
    else
		printf("dm9000 io mode is 16bit.....!\n");

    iow(DM9000_TXPLH, (len>>8) & 0x0ff);
    iow(DM9000_TXPLL, len & 0x0ff);
	
    iow(DM9000_TCR, 0x01);//�������ݵ���̫����

	while(!(ior(DM9000_NSR)&0x0C))
	    dm9000_delay(5);    
    
    iow(DM9000_NSR, 0x00);//���״̬�Ĵ��������ڷ�������û�������жϣ���˲��ش����жϱ�־λ

    iow(DM9000_IMR, 0x81);//DM9000�����Ľ����ж�ʹ��
}

//uint16_t dm9000x_receivepacket(uint8_t* packet, uint16_t maxlen)
uint16_t dm9000x_receivepacket(u16 port)
{
  unsigned int temp;  
//    unsigned char packet[1512];
    unsigned char ready;
	unsigned char rx_io_mode;
	unsigned int  rx_status = 0x00;
	unsigned int  rx_length = 0x00;
	unsigned int  rx_length_bak = 0x00;
  int i;

    ready = 0;//ϣ����ȡ����01H��


/*��������жϱ�־λ*/

    ready = ior(DM9000_MRCMDX); // ��һ�ζ�ȡ��һ���ȡ������ 00H
    ready = ior(DM9000_MRCMDX); // �ڶ��ζ�ȡ�����ܻ�ȡ������
//		printf(" ready = %x \r\n", ready);    
    if((ready & 0x0ff) != 0x01)
        {
        ready = ior(DM9000_MRCMDX); // �ڶ��ζ�ȡ�����ܻ�ȡ������
        if((ready & 0x01) != 0x01)
        {
            if((ready & 0x01) != 0x00) //���ڶ��ζ�ȡ���Ĳ��� 01H �� 00H �����ʾû�г�ʼ���ɹ�
            {
  //          printf("2.1  %x \r\n", ready);    
            goto DM9006_reset;     
            }
            goto rx_erro;
         }
       }

	rx_io_mode = ior(DM9000_ISR) >> 7;
//	printf("rx_io_mode %x \r\n", rx_io_mode);
  
	if(DM9000X_BYTE_MODE == (rx_io_mode & 0x01))
		{
		rx_status = ior(DM9000_MRCMD) + (ior(DM9000_MRCMD) << 8);
		rx_length = ior(DM9000_MRCMD) + (ior(DM9000_MRCMD) << 8);
//		printf("RX packet rx_status %x; rx_length %x \r\n", rx_status, rx_length);
//		if(!(rx_status & 0xbf00) && (rx_length < 1522))
		if((!(rx_status & 0x0300)) && (rx_length < 1522))
			{
			 if (rx_length > 0){
			  rx_length_bak = rx_length;
//	   printf("RX packet rx_status %x; rx_length %x \r\n", rx_status, rx_length);
//			  while(rx_length_bak--)
								
				for (i=0; i<rx_length_bak; i++) 
			  {
			    //*(packet++) = ior(DM9000_MRCMD);
					temp = ior(DM9000_MRCMD);
					if(i==0x17){if(temp!=6)rx_length = 0;}   //jun add,type offset 0x17=06tcp/17udp	
					if (i == 0x24)
						{ //check offset 0x22 = 0x1F   (8000 = 0x1F40)   ��0080=0x0050��
						if(temp != (port/256))
							{
//						if(temp != 0x01){						
							rx_length = 0; 
              }
						else
    				{ //after check offset 0x22 = 0x1F, check offset 0x23 = 0x40 
						i++;  // i == 0x23
            temp = ior(DM9000_MRCMD);  							
						if (temp != (port%256))
							{
//						if (temp != 0xbd){							
							rx_length = 0; 
              }//else printf(" Get destination port = 8000 packet !!!!  rx_length = %x \r\n", rx_length);						
						} //end of else
					} //end of if(i == 0x22)
			   }
			  
			//	if((ior(DM9000_RCSR)&0x0008)==0)rx_length = 0;//jun add
				 
				 
			  //Stone add for debug   
			  if (rx_status == 0x401)
          {
//           if ((!(packet[0] & 0x1)))
//           if (packet[6] == 0x64)   //Jerry PC ping 178        
           { 
//            printf("RX packet rx_status %x; rx_length %x \r\n", rx_status, rx_length);
//            printf("DA : %x %x %x %x %x %x \r\n",packet[0], packet[1], packet[2], packet[3], packet[4], packet[5]);
//            printf("SA : %x %x %x %x %x %x \r\n",packet[6], packet[7], packet[8], packet[9], packet[10], packet[11]);
            } 
           }  
			  }  
//			printf("OK - REG F4 : %x; REG F5 : %x; rx_length %x \r\n", ior(DM9000_MRRL), ior(DM9000_MRRH), rx_length);    
			}
		else
			{
			if (rx_status == 0xffff)
			  if (rx_length == 0xffff)
			   if (( i= ior(DM9000_MRRL)) == 0x03)
			     {
//			printf("Fail 0 - REG F4 : %x; \r\n", i);
//			printf("RX packet rx_status %x; rx_length %x \r\n", rx_status, rx_length);
			      while (1);
			      } 
//			for (i=0; i<6; i++)
//	        printf("%x ", ior(DM9000_MRCMD));
      
//			iow(DM9000_IMR, 0x80);//��Ļ�����ж�
DM9006_reset:

      iow(DM9000_NCR, 0x03);

	/* ��ʱ20us���ϵȴ�������λ��� */
      dm9000_delay(5000);
			
    
	/* ��λ��ɣ�������������ģʽ */
      iow(DM9000_NCR, 0x00);
//      iow(DM9000_IMR, 0x81);//�������ж�
	//		printf("Fail 1 - REG F4 : %x REG F5 : %x \r\n", ior(DM9000_MRRL), ior(DM9000_MRRH));

       iow(DM9000_NCR, 0x03);

    dm9000_delay(5000);
    iow(DM9000_NCR, 0x00);

    /*���������DM9000�ĸ�λ����*/

	 /* ���� GPCR(1EH) bit[0]=1��ʹDM9000��GPIO3Ϊ��� */
	iow(DM9000_GPCR, 0x01);

    /* GPR bit[0]=0 ʹDM9000��GPIO3���Ϊ���Լ����ڲ�PHY */
    iow(DM9000_GPR, 0x00);


	  iow(DM9KS_DBDC, 0x63);
	  
//	    printf("\r\n"); 
//			for (i=0; i<100; i++)
//          printf("."); 					
//      printf("\r\n"); 				
//			printf("bad data!\r\n");
			
			goto rx_erro;
			}	
		}
    else if(DM9000X_WORD_MODE == (rx_io_mode & 0x01))
		{
//		printf("dm9000 io mode is 16bit.....!\n");
    	}

    return rx_length;
    
    rx_erro:
//        printf("3. %x \r\n", ready);
		return 0;
}


/**
u32 mib_read(u8 index)
{
 u32 temp;
 u8  tmp;
 iow(DM9KS_PIndex, 0); //switch port index first!
 iow(0x80, index);  //read MIB index 4
 while(1)
 {
//  ior(0x28);
  tmp = ior(0x80);
//  printf("ior(0x80) = %x \r\n", tmp);
  
  if (tmp & 0x80)
   break;
  }
  temp = ior(0x81);
//  printf("temp (0x81) = %x \r\n", temp);
  temp |= (ior(0x82) <<8);
  temp |= (ior(0x83) <<16);
  temp |= (ior(0x84) << 24);
//  if (temp > 0)
//    printf("temp = %x \r\n", temp);
//  if (temp > 0)
//    printf("XXXXXXX  temp = %x \r\n", temp);
      
  return temp;
}
**/
